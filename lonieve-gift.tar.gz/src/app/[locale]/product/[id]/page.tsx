import { notFound } from 'next/navigation';
import type { Locale } from '@/lib/i18n/config';
import { getTranslations } from '@/lib/i18n/translations';
import { createClient } from '@/lib/supabase/server';
import { ProductConfigurator } from '@/components/product/ProductConfigurator';

interface ProductPageProps {
  params: { 
    locale: Locale;
    id: string;
  };
}

export default async function ProductPage({ params }: ProductPageProps) {
  const t = getTranslations(params.locale);
  const supabase = await createClient();

  const { data: product, error } = await supabase
    .from('products')
    .select('*')
    .eq('id', params.id)
    .eq('is_active', true)
    .single();

  if (error || !product) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Left: Product Info */}
          <div className="space-y-6">
            {/* Brand Header */}
            <div>
              <h1 className="text-3xl md:text-4xl font-display font-bold text-white mb-2">
                {product.brand}
              </h1>
              <p className="text-lg text-text-secondary">{product.name}</p>
            </div>

            {/* Description */}
            {product.description && (
              <div className="p-6 bg-background-card border border-white/10 rounded-xl">
                <p className="text-text-secondary">{product.description}</p>
              </div>
            )}

            {/* Key Info */}
            <div className="p-6 bg-background-card border border-white/10 rounded-xl space-y-4">
              <div className="flex items-start gap-3">
                <div className="text-2xl">⚡</div>
                <div>
                  <h3 className="font-semibold text-white mb-1">
                    {t.product.deliveryTime}
                  </h3>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="text-2xl">✓</div>
                <div>
                  <h3 className="font-semibold text-white mb-1">
                    {t.product.guarantee}
                  </h3>
                </div>
              </div>
            </div>

            {/* About Card */}
            <div className="p-6 bg-background-card border border-white/10 rounded-xl">
              <h2 className="text-xl font-semibold text-white mb-4">
                {t.product.aboutCard}
              </h2>
              
              {product.instructions && (
                <div className="mb-4">
                  <h3 className="font-medium text-white mb-2">{t.product.howToRedeem}</h3>
                  <p className="text-sm text-text-secondary whitespace-pre-line">
                    {product.instructions}
                  </p>
                </div>
              )}

              {product.terms && (
                <div>
                  <h3 className="font-medium text-white mb-2">{t.product.terms}</h3>
                  <p className="text-sm text-text-secondary whitespace-pre-line">
                    {product.terms}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Right: Configurator */}
          <div className="lg:sticky lg:top-24 h-fit">
            <ProductConfigurator product={product} locale={params.locale} />
          </div>
        </div>
      </div>
    </div>
  );
}

