'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import type { Locale } from '@/lib/i18n/config';
import { getTranslations } from '@/lib/i18n/translations';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Badge } from '@/components/ui/Badge';
import { formatCurrency } from '@/lib/utils';

interface CheckoutConfig {
  productId: string;
  productName?: string;
  nominal: number;
  price: number;
  deliveryType: 'myself' | 'gift';
  recipientEmail?: string;
  recipientName?: string;
  giftMessage?: string;
  deliveryDate?: string;
}

export default function CheckoutPage({ params }: { params: { locale: Locale } }) {
  const t = getTranslations(params.locale);
  const router = useRouter();
  const [config, setConfig] = useState<CheckoutConfig | null>(null);
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [agreedToTerms, setAgreedToTerms] = useState(false);

  useEffect(() => {
    const stored = sessionStorage.getItem('checkout_config');
    if (!stored) {
      router.push(`/${params.locale}/catalog`);
      return;
    }
    setConfig(JSON.parse(stored));
    
    // Track checkout start
    const { Analytics } = require('@/lib/analytics/tracking');
    Analytics.checkoutStart();
  }, [params.locale, router]);

  const handleCheckout = async () => {
    if (!config || !email) return;

    setIsLoading(true);
    setError('');
    
    // Track checkout submit
    const { Analytics } = require('@/lib/analytics/tracking');
    Analytics.checkoutSubmit(config.productId, config.price);

    try {
      const response = await fetch('/api/orders/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          productId: config.productId,
          nominal: config.nominal,
          price: config.price,
          recipientEmail: config.recipientEmail,
          recipientName: config.recipientName,
          recipientMessage: config.giftMessage,
          deliveryDate: config.deliveryDate,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create order');
      }

      const data = await response.json();
      
      // Redirect to Cardlink payment page
      if (data.paymentUrl) {
        window.location.href = data.paymentUrl;
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      setIsLoading(false);
    }
  };

  if (!config) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-text-secondary">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-display font-bold text-white mb-8">
            {t.checkout.title}
          </h1>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left: Contact Info */}
            <div className="space-y-6">
              <Card className="p-6">
                <h2 className="text-xl font-semibold text-white mb-4">
                  Contact Information
                </h2>
                <Input
                  label={t.checkout.yourEmail}
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder={t.checkout.emailPlaceholder}
                  required
                />
                <p className="text-xs text-text-secondary mt-2">
                  {t.product.deliveryTime}
                </p>
              </Card>

              {config.deliveryType === 'gift' && (
                <Card className="p-6">
                  <h2 className="text-xl font-semibold text-white mb-4">
                    Gift Details
                  </h2>
                  <div className="space-y-3 text-sm">
                    <div>
                      <span className="text-text-secondary">{t.product.recipientEmail}: </span>
                      <span className="text-white">{config.recipientEmail}</span>
                    </div>
                    {config.recipientName && (
                      <div>
                        <span className="text-text-secondary">{t.product.recipientName}: </span>
                        <span className="text-white">{config.recipientName}</span>
                      </div>
                    )}
                    {config.giftMessage && (
                      <div>
                        <span className="text-text-secondary">{t.product.giftMessage}: </span>
                        <p className="text-white mt-1">{config.giftMessage}</p>
                      </div>
                    )}
                  </div>
                </Card>
              )}
            </div>

            {/* Right: Order Summary */}
            <div>
              <Card className="p-6 space-y-6">
                <h2 className="text-xl font-semibold text-white">
                  {t.checkout.orderSummary}
                </h2>

                <div className="space-y-4">
                  <div className="pb-4 border-b border-white/10">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-text-secondary">{t.checkout.product}</span>
                      <span className="text-white font-medium">Gift Card</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-text-secondary">{t.checkout.amount}</span>
                      <span className="text-white font-medium">
                        {formatCurrency(config.nominal, 'USD')}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-text-secondary">Nominal</span>
                      <span className="text-white">
                        {formatCurrency(config.nominal, 'USD')}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-text-secondary">{t.checkout.discount}</span>
                      <Badge variant="success">
                        -{formatCurrency(config.nominal - config.price, 'USD')}
                      </Badge>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-white/10">
                    <div className="flex items-center justify-between text-xl font-bold">
                      <span className="text-white">{t.checkout.total}</span>
                      <span className="text-primary">
                        {formatCurrency(config.price, 'USD')}
                      </span>
                    </div>
                  </div>
                </div>

                {error && (
                  <div className="p-4 bg-error/10 border border-error/20 rounded-lg text-error text-sm">
                    {error}
                  </div>
                )}

                {/* Terms Agreement Checkbox */}
                <div className="flex items-start gap-3 p-4 bg-background-lighter rounded-lg border border-white/10">
                  <input
                    type="checkbox"
                    id="terms-agreement"
                    checked={agreedToTerms}
                    onChange={(e) => setAgreedToTerms(e.target.checked)}
                    className="mt-1 w-4 h-4 rounded border-white/20 bg-background text-primary focus:ring-primary focus:ring-offset-background"
                  />
                  <label htmlFor="terms-agreement" className="text-sm text-text-secondary cursor-pointer">
                    I have read and agree to the{' '}
                    <a
                      href={`/${params.locale}/terms`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:text-primary-light underline"
                    >
                      Terms of Service
                    </a>
                    {', '}
                    <a
                      href={`/${params.locale}/privacy`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:text-primary-light underline"
                    >
                      Privacy Policy
                    </a>
                    {', and '}
                    <a
                      href={`/${params.locale}/refund`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:text-primary-light underline"
                    >
                      Refund Policy
                    </a>
                    . I understand that all sales are final and no refunds will be provided after delivery.
                  </label>
                </div>

                <Button
                  size="lg"
                  className="w-full"
                  onClick={handleCheckout}
                  isLoading={isLoading}
                  disabled={!email || !agreedToTerms || isLoading}
                >
                  {t.checkout.payNow}
                </Button>

                <div className="text-xs text-text-secondary text-center">
                  Secure payment powered by Cardlink
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

