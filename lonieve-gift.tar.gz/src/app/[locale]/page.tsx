import Link from 'next/link';
import type { Locale } from '@/lib/i18n/config';
import { getTranslations } from '@/lib/i18n/translations';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { createClient } from '@/lib/supabase/server';
import { formatCurrency, calculateDiscountedPrice } from '@/lib/utils';

export default async function HomePage({ params }: { params: { locale: Locale } }) {
  const t = getTranslations(params.locale);
  const supabase = await createClient();

  // Fetch top products (best sellers)
  const { data: topProducts } = await supabase
    .from('products')
    .select('*')
    .eq('is_active', true)
    .order('discount_percentage', { ascending: false })
    .limit(6);

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-primary-50 via-white to-background-secondary">
        {/* Animated gradient orbs */}
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-3xl animate-pulse delay-1000" />
        
        {/* Grid pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#3b82f605_1px,transparent_1px),linear-gradient(to_bottom,#3b82f605_1px,transparent_1px)] bg-[size:4rem_4rem]" />
        
        <div className="container relative mx-auto px-4 py-24 md:py-32">
          <div className="mx-auto max-w-4xl text-center space-y-8">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary-50 border border-primary/20 rounded-full">
              <span className="w-2 h-2 bg-primary rounded-full animate-pulse" />
              <span className="text-sm font-medium text-primary">Trusted by 10,000+ customers</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-display font-bold text-balance leading-tight">
              <span className="text-text-primary">{t.hero.title.split('35%')[0]}</span>
              <span className="gradient-primary bg-clip-text text-transparent">35%</span>
              <span className="text-text-primary">{t.hero.title.split('35%')[1]}</span>
            </h1>
            
            <p className="text-lg md:text-xl text-text-secondary max-w-2xl mx-auto">
              {t.hero.subtitle}
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4">
              <Link href={`/${params.locale}/catalog`}>
                <Button size="lg" variant="primary" className="group">
                  {t.hero.ctaPrimary}
                  <svg className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </Button>
              </Link>
              <Link href={`/${params.locale}#how-it-works`}>
                <Button size="lg" variant="outline">
                  {t.hero.ctaSecondary}
                </Button>
              </Link>
            </div>

            {/* Brand Logos */}
            <div className="flex flex-wrap justify-center items-center gap-8 pt-12">
              {['Amazon', 'Apple', 'Google Play', 'PlayStation', 'Steam', 'Netflix'].map((brand) => (
                <div key={brand} className="text-sm font-medium text-text-tertiary hover:text-text-secondary transition-colors">
                  {brand}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: '⚡',
                title: t.features.instantDelivery.title,
                description: t.features.instantDelivery.description,
                color: 'from-blue-500 to-cyan-500',
              },
              {
                icon: '🛡️',
                title: t.features.trustedProviders.title,
                description: t.features.trustedProviders.description,
                color: 'from-green-500 to-emerald-500',
              },
              {
                icon: '✓',
                title: t.features.guarantee.title,
                description: t.features.guarantee.description,
                color: 'from-purple-500 to-pink-500',
              },
              {
                icon: '🔒',
                title: t.features.securePayment.title,
                description: t.features.securePayment.description,
                color: 'from-orange-500 to-red-500',
              },
            ].map((feature, index) => (
              <Card key={index} hover className="p-6 text-center group cursor-default">
                <div className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br ${feature.color} text-white text-3xl mb-4 group-hover:scale-110 transition-transform`}>
                  {feature.icon}
                </div>
                <h3 className="text-lg font-semibold text-text-primary mb-2">{feature.title}</h3>
                <p className="text-sm text-text-secondary leading-relaxed">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Top Products Section */}
      <section className="py-20 bg-background-secondary">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary-50 border border-primary/20 rounded-full mb-4">
              <span className="text-sm font-medium text-primary">🔥 Hot Deals</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-display font-bold text-text-primary mb-4">
              Best Sellers
            </h2>
            <p className="text-text-secondary text-lg">
              {t.catalog.upTo} 35% {t.catalog.discount}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {topProducts?.map((product) => {
              const discountedPrice = calculateDiscountedPrice(
                product.min_nominal,
                product.discount_percentage
              );

              return (
                <Card key={product.id} hover className="overflow-hidden group">
                  <div className="p-6 space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-text-primary mb-1 group-hover:text-primary transition-colors">
                          {product.brand}
                        </h3>
                        <p className="text-sm text-text-secondary">
                          {product.region}
                        </p>
                      </div>
                      <Badge variant="primary">
                        {product.discount_percentage}% {t.catalog.discount}
                      </Badge>
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-baseline gap-2">
                        <span className="text-2xl font-bold text-primary">
                          {formatCurrency(discountedPrice, product.currency as any)}
                        </span>
                        <span className="text-sm text-text-muted line-through">
                          {formatCurrency(product.min_nominal, product.currency as any)}
                        </span>
                      </div>
                      <p className="text-xs text-text-secondary">
                        {t.product.from} {formatCurrency(product.min_nominal, product.currency as any)}
                      </p>
                    </div>

                    <Link href={`/${params.locale}/product/${product.id}`}>
                      <Button className="w-full" variant="primary">
                        {t.catalog.configure}
                      </Button>
                    </Link>
                  </div>
                </Card>
              );
            })}
          </div>

          <div className="text-center mt-12">
            <Link href={`/${params.locale}/catalog`}>
              <Button variant="outline" size="lg">
                {t.common.viewAll}
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-20 bg-background-lighter">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">
              {t.howItWorks.title}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              {
                step: '1',
                title: t.howItWorks.step1.title,
                description: t.howItWorks.step1.description,
              },
              {
                step: '2',
                title: t.howItWorks.step2.title,
                description: t.howItWorks.step2.description,
              },
              {
                step: '3',
                title: t.howItWorks.step3.title,
                description: t.howItWorks.step3.description,
              },
            ].map((step) => (
              <div key={step.step} className="text-center space-y-4">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 border-2 border-primary text-primary text-2xl font-bold">
                  {step.step}
                </div>
                <h3 className="text-xl font-semibold text-white">{step.title}</h3>
                <p className="text-text-secondary">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary/10 via-primary/5 to-primary/10">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">
            Ready to save up to 35%?
          </h2>
          <p className="text-text-secondary mb-8 max-w-2xl mx-auto">
            Get your digital gift card in 2 minutes
          </p>
          <Link href={`/${params.locale}/catalog`}>
            <Button size="lg" variant="primary">
              {t.hero.ctaPrimary}
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}

