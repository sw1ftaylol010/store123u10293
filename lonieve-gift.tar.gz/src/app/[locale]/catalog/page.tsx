import Link from 'next/link';
import type { Locale } from '@/lib/i18n/config';
import { getTranslations } from '@/lib/i18n/translations';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { createClient } from '@/lib/supabase/server';
import { formatCurrency, calculateDiscountedPrice } from '@/lib/utils';
import { CatalogFilters } from '@/components/catalog/CatalogFilters';

interface CatalogPageProps {
  params: { locale: Locale };
  searchParams: {
    brand?: string;
    category?: string;
    region?: string;
  };
}

export default async function CatalogPage({ params, searchParams }: CatalogPageProps) {
  const t = getTranslations(params.locale);
  const supabase = await createClient();

  // Build query
  let query = supabase
    .from('products')
    .select('*')
    .eq('is_active', true);

  if (searchParams.brand) {
    query = query.eq('brand', searchParams.brand);
  }
  if (searchParams.category) {
    query = query.eq('category', searchParams.category);
  }
  if (searchParams.region) {
    query = query.eq('region', searchParams.region);
  }

  const { data: products } = await query.order('brand');

  // Get unique values for filters
  const { data: allProducts } = await supabase
    .from('products')
    .select('brand, category, region')
    .eq('is_active', true);

  const brands = [...new Set(allProducts?.map((p) => p.brand) || [])];
  const categories = [...new Set(allProducts?.map((p) => p.category) || [])];
  const regions = [...new Set(allProducts?.map((p) => p.region) || [])];

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-display font-bold text-white mb-2">
            {t.catalog.title}
          </h1>
          <p className="text-text-secondary">
            {products?.length || 0} products available
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <aside className="lg:col-span-1">
            <CatalogFilters
              locale={params.locale}
              brands={brands}
              categories={categories}
              regions={regions}
              currentFilters={searchParams}
            />
          </aside>

          {/* Products Grid */}
          <div className="lg:col-span-3">
            {products && products.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {products.map((product) => {
                  const discountedPrice = calculateDiscountedPrice(
                    product.min_nominal,
                    product.discount_percentage
                  );

                  return (
                    <Card key={product.id} hover className="overflow-hidden">
                      <div className="p-6 space-y-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h3 className="text-lg font-semibold text-white mb-1">
                              {product.brand}
                            </h3>
                            <p className="text-sm text-text-secondary">
                              {product.region}
                            </p>
                          </div>
                          <Badge variant="primary">
                            {product.discount_percentage}% {t.catalog.discount}
                          </Badge>
                        </div>

                        <div>
                          <p className="text-xs text-text-muted mb-1">
                            {t.product.from}
                          </p>
                          <div className="flex items-baseline gap-2">
                            <span className="text-2xl font-bold text-primary">
                              {formatCurrency(discountedPrice, product.currency as any)}
                            </span>
                            <span className="text-sm text-text-muted line-through">
                              {formatCurrency(product.min_nominal, product.currency as any)}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 text-xs text-text-secondary">
                          <span className="px-2 py-1 bg-white/5 rounded">
                            {product.category}
                          </span>
                        </div>

                        <Link href={`/${params.locale}/product/${product.id}`}>
                          <Button className="w-full" variant="primary">
                            {t.catalog.configure}
                          </Button>
                        </Link>
                      </div>
                    </Card>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-16">
                <p className="text-text-secondary text-lg">{t.catalog.noResults}</p>
                <Link href={`/${params.locale}/catalog`}>
                  <Button variant="outline" className="mt-4">
                    Clear filters
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

