import Link from 'next/link';
import type { Locale } from '@/lib/i18n/config';
import { getTranslations } from '@/lib/i18n/translations';

interface FooterProps {
  locale: Locale;
}

export function Footer({ locale }: FooterProps) {
  const t = getTranslations(locale);

  return (
    <footer className="border-t border-border bg-background-secondary">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="text-2xl font-display font-bold">
              <span className="text-primary">Lonieve</span>
              <span className="text-text-primary"> Gift</span>
            </div>
            <p className="text-sm text-text-secondary">
              Premium digital gift cards with instant delivery
            </p>
          </div>

          {/* Company */}
          <div>
            <h3 className="font-semibold text-text-primary mb-4">{t.footer.about}</h3>
            <ul className="space-y-2">
              <li>
                <Link href={`/${locale}/about`} className="text-sm text-text-secondary hover:text-primary transition-colors">
                  {t.footer.about}
                </Link>
              </li>
              <li>
                <Link href={`/${locale}/contact`} className="text-sm text-text-secondary hover:text-primary transition-colors">
                  {t.footer.contact}
                </Link>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="font-semibold text-text-primary mb-4">{t.nav.support}</h3>
            <ul className="space-y-2">
              <li>
                <Link href={`/${locale}/faq`} className="text-sm text-text-secondary hover:text-primary transition-colors">
                  {t.footer.faq}
                </Link>
              </li>
              <li>
                <Link href={`/${locale}/support`} className="text-sm text-text-secondary hover:text-primary transition-colors">
                  {t.nav.support}
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="font-semibold text-text-primary mb-4">Legal</h3>
            <ul className="space-y-2">
              <li>
                <Link href={`/${locale}/terms`} className="text-sm text-text-secondary hover:text-primary transition-colors">
                  {t.footer.terms}
                </Link>
              </li>
              <li>
                <Link href={`/${locale}/privacy`} className="text-sm text-text-secondary hover:text-primary transition-colors">
                  {t.footer.privacy}
                </Link>
              </li>
              <li>
                <Link href={`/${locale}/refund`} className="text-sm text-text-secondary hover:text-primary transition-colors">
                  {t.footer.refund}
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-border">
          <p className="text-center text-sm text-text-secondary">
            {t.footer.copyright}
          </p>
        </div>
      </div>
    </footer>
  );
}

