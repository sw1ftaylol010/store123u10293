import { redirect } from 'next/navigation';
import Link from 'next/link';
import type { Locale } from '@/lib/i18n/config';
import { getTranslations } from '@/lib/i18n/translations';
import { createClient } from '@/lib/supabase/server';

export default async function AdminLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { locale: Locale };
}) {
  const t = getTranslations(params.locale);
  const supabase = await createClient();

  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    redirect(`/${params.locale}/auth/signin?redirect=/admin`);
  }

  // Check if user is admin
  const { data: profile } = await supabase
    .from('user_profiles')
    .select('role')
    .eq('id', user.id)
    .single();

  if (!profile || !['admin', 'super_admin'].includes(profile.role)) {
    redirect(`/${params.locale}`);
  }

  // Count unresolved alerts
  const { data: unresolvedAlerts } = await supabase
    .from('system_notifications')
    .select('id', { count: 'exact' })
    .eq('is_resolved', false);

  const alertCount = unresolvedAlerts?.length || 0;

  const navItems = [
    { href: `/${params.locale}/admin`, label: t.admin.overview, icon: '📊' },
    { href: `/${params.locale}/admin/copilot`, label: 'AI Copilot', icon: '🤖' },
    { href: `/${params.locale}/admin/realtime`, label: 'Real-time', icon: '⚡' },
    { href: `/${params.locale}/admin/insights`, label: 'BI Insights', icon: '🧠' },
    { href: `/${params.locale}/admin/unit-economics`, label: 'Unit Economics', icon: '💎' },
    { href: `/${params.locale}/admin/financial`, label: 'Financial', icon: '💰' },
    { href: `/${params.locale}/admin/rfm`, label: 'RFM Segments', icon: '📊' },
    { href: `/${params.locale}/admin/orders`, label: t.admin.orders, icon: '📦' },
    { href: `/${params.locale}/admin/codes`, label: t.admin.codes, icon: '🎟️' },
    { href: `/${params.locale}/admin/products`, label: t.admin.products, icon: '🏷️' },
    { href: `/${params.locale}/admin/partners`, label: 'Partners', icon: '🤝' },
    { href: `/${params.locale}/admin/alerts`, label: 'Alerts', icon: '🔔', badge: alertCount > 0 ? alertCount : undefined },
    { href: `/${params.locale}/admin/funnel`, label: 'Funnel', icon: '🔄' },
    { href: `/${params.locale}/admin/channels`, label: 'Channels', icon: '📢' },
    { href: `/${params.locale}/admin/cohorts`, label: 'Cohorts', icon: '👥' },
    { href: `/${params.locale}/admin/crm`, label: 'CRM', icon: '📧' },
    { href: `/${params.locale}/admin/data-quality`, label: 'Data Quality', icon: '🔍' },
    { href: `/${params.locale}/admin/health`, label: 'Health', icon: '🏥' },
    { href: `/${params.locale}/admin/webhooks`, label: 'Webhooks', icon: '🔗' },
    { href: `/${params.locale}/admin/delivery-logs`, label: 'Delivery Logs', icon: '🔒' },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 min-h-screen bg-background-card border-r border-white/10">
          <div className="p-6">
            <h2 className="text-xl font-display font-bold text-white mb-2">
              Admin Panel
            </h2>
            <p className="text-sm text-text-secondary">{user.email}</p>
          </div>
          
          <nav className="px-3">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="flex items-center gap-3 px-3 py-2 rounded-lg text-text-secondary hover:bg-white/5 hover:text-white transition-colors mb-1 relative"
              >
                <span className="text-xl">{item.icon}</span>
                <span className="text-sm font-medium">{item.label}</span>
                {item.badge && (
                  <span className="ml-auto bg-error text-white text-xs px-2 py-0.5 rounded-full">
                    {item.badge}
                  </span>
                )}
              </Link>
            ))}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1">
          {children}
        </main>
      </div>
    </div>
  );
}

