import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { z } from 'zod';

// Валидация payload
const eventSchema = z.object({
  event_type: z.string().min(1).max(100),
  session_id: z.string().min(1),
  visitor_id: z.string().optional(),
  url: z.string().optional(),
  referrer: z.string().nullable().optional(),
  utm_source: z.string().optional(),
  utm_medium: z.string().optional(),
  utm_campaign: z.string().optional(),
  utm_content: z.string().optional(),
  utm_term: z.string().optional(),
  data: z.record(z.any()).optional(),
  timestamp: z.string().optional(),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Валидация
    const validatedData = eventSchema.parse(body);
    
    const supabase = await createClient();
    
    // Получаем user_id если авторизован
    const { data: { user } } = await supabase.auth.getUser();
    
    // Вставляем событие
    const { error } = await supabase.from('events').insert({
      event_type: validatedData.event_type,
      session_id: validatedData.session_id,
      user_id: user?.id,
      visitor_id: validatedData.visitor_id,
      url: validatedData.url,
      referrer: validatedData.referrer,
      utm_source: validatedData.utm_source,
      utm_medium: validatedData.utm_medium,
      utm_campaign: validatedData.utm_campaign,
      utm_content: validatedData.utm_content,
      utm_term: validatedData.utm_term,
      event_data: validatedData.data,
      ip_address: request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip'),
      user_agent: request.headers.get('user-agent'),
    });
    
    if (error) {
      console.error('Failed to insert event:', error);
      return NextResponse.json({ error: 'Failed to track event' }, { status: 500 });
    }
    
    return NextResponse.json({ success: true });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid event data', details: error.errors },
        { status: 400 }
      );
    }
    
    console.error('Event tracking error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
