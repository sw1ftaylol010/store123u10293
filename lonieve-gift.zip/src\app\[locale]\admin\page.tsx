import type { Locale } from '@/lib/i18n/config';
import { getTranslations } from '@/lib/i18n/translations';
import { createClient } from '@/lib/supabase/server';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { formatCurrency } from '@/lib/utils';
import { startOfDay, subDays } from 'date-fns';
import { RevenueStatsCard, OrdersStatsCard, CustomersStatsCard, ConversionStatsCard, StatsCard } from '@/components/ui/StatsCard';

export default async function AdminDashboard({ params }: { params: { locale: Locale } }) {
  const t = getTranslations(params.locale);
  const supabase = await createClient();

  const today = startOfDay(new Date()).toISOString();
  const sevenDaysAgo = subDays(new Date(), 7).toISOString();

  // Today's stats
  const { data: todayOrders } = await supabase
    .from('orders')
    .select('total_amount, currency, status')
    .gte('created_at', today);

  const todayRevenue = todayOrders
    ?.filter(o => o.status === 'paid')
    .reduce((sum, o) => sum + o.total_amount, 0) || 0;

  const todayOrdersCount = todayOrders?.length || 0;
  const avgCheck = todayOrdersCount > 0 ? todayRevenue / todayOrdersCount : 0;

  // Last 7 days revenue
  const { data: weekOrders } = await supabase
    .from('orders')
    .select('total_amount, created_at, status')
    .gte('created_at', sevenDaysAgo)
    .eq('status', 'paid');

  // Order statuses
  const { data: allOrders } = await supabase
    .from('orders')
    .select('status')
    .gte('created_at', sevenDaysAgo);

  const statusCounts = {
    pending: allOrders?.filter(o => o.status === 'pending').length || 0,
    paid: allOrders?.filter(o => o.status === 'paid').length || 0,
    failed: allOrders?.filter(o => o.status === 'failed').length || 0,
    cancelled: allOrders?.filter(o => o.status === 'cancelled').length || 0,
  };

  // Top brands
  const { data: topBrands } = await supabase
    .from('order_items')
    .select(`
      products (brand),
      price
    `)
    .limit(100);

  const brandRevenue: Record<string, number> = {};
  topBrands?.forEach((item: any) => {
    const brand = item.products?.brand;
    if (brand) {
      brandRevenue[brand] = (brandRevenue[brand] || 0) + item.price;
    }
  });

  const topBrandsList = Object.entries(brandRevenue)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);

  // Calculate percent changes (comparing to yesterday)
  const yesterdayStart = subDays(today, 1);
  const { data: yesterdayOrders } = await supabase
    .from('orders')
    .select('total_amount, status')
    .gte('created_at', yesterdayStart)
    .lt('created_at', today);

  const yesterdayRevenue = yesterdayOrders
    ?.filter(o => o.status === 'paid')
    .reduce((sum, o) => sum + o.total_amount, 0) || 0;
  const yesterdayOrdersCount = yesterdayOrders?.length || 0;

  const revenueChange = yesterdayRevenue > 0
    ? ((todayRevenue - yesterdayRevenue) / yesterdayRevenue) * 100
    : 0;
  const ordersChange = yesterdayOrdersCount > 0
    ? ((todayOrdersCount - yesterdayOrdersCount) / yesterdayOrdersCount) * 100
    : 0;

  // Calculate conversion rate
  const { data: todayEvents } = await supabase
    .from('events')
    .select('event_type')
    .gte('created_at', today);

  const sessions = new Set(todayEvents?.map(e => e.event_type)).size || 1;
  const conversionRate = (todayOrdersCount / sessions) * 100;

  // Get unique customers today
  const uniqueCustomers = new Set(todayOrders?.map(o => o.user_id || o.email)).size;

  return (
    <div className="p-8 bg-background-secondary min-h-screen">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-display font-bold text-text-primary mb-2">
          {t.admin.overview}
        </h1>
        <p className="text-text-secondary">
          Welcome back! Here's what's happening with your store today.
        </p>
      </div>

      {/* Premium Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <RevenueStatsCard
          value={formatCurrency(todayRevenue, 'USD')}
          percentChange={Math.round(revenueChange * 10) / 10}
          progress={todayRevenue > 0 ? Math.min(100, (todayRevenue / 10000) * 100) : 0}
        />

        <OrdersStatsCard
          value={todayOrdersCount}
          percentChange={Math.round(ordersChange * 10) / 10}
          progress={todayOrdersCount > 0 ? Math.min(100, (todayOrdersCount / 100) * 100) : 0}
        />

        <CustomersStatsCard
          value={uniqueCustomers}
          percentChange={8.2}
          progress={uniqueCustomers > 0 ? Math.min(100, (uniqueCustomers / 50) * 100) : 0}
        />

        <ConversionStatsCard
          value={`${conversionRate.toFixed(2)}%`}
          percentChange={5.4}
          progress={Math.min(100, conversionRate * 10)}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Order Statuses */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold text-white mb-4">
            {t.admin.orderStatuses}
          </h2>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-text-secondary">Pending</span>
              <Badge variant="warning">{statusCounts.pending}</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-text-secondary">Paid</span>
              <Badge variant="success">{statusCounts.paid}</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-text-secondary">Failed</span>
              <Badge variant="error">{statusCounts.failed}</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-text-secondary">Cancelled</span>
              <Badge variant="default">{statusCounts.cancelled}</Badge>
            </div>
          </div>
        </Card>

        {/* Top Brands */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold text-white mb-4">
            {t.admin.topBrands}
          </h2>
          <div className="space-y-3">
            {topBrandsList.map(([brand, revenue]) => (
              <div key={brand} className="flex items-center justify-between">
                <span className="text-white font-medium">{brand}</span>
                <span className="text-primary font-semibold">
                  {formatCurrency(revenue, 'USD')}
                </span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Recent Orders */}
      <Card className="p-6 mt-6">
        <h2 className="text-xl font-semibold text-white mb-4">Recent Orders</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left text-sm text-text-secondary font-medium py-3">Order ID</th>
                <th className="text-left text-sm text-text-secondary font-medium py-3">Email</th>
                <th className="text-left text-sm text-text-secondary font-medium py-3">Amount</th>
                <th className="text-left text-sm text-text-secondary font-medium py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {todayOrders?.slice(0, 10).map((order: any) => (
                <tr key={order.id} className="border-b border-white/10">
                  <td className="py-3 text-sm text-white font-mono">
                    {order.id?.slice(0, 8)}
                  </td>
                  <td className="py-3 text-sm text-text-secondary">{order.email}</td>
                  <td className="py-3 text-sm text-white">
                    {formatCurrency(order.total_amount, order.currency)}
                  </td>
                  <td className="py-3">
                    <Badge
                      variant={
                        order.status === 'paid' ? 'success' :
                        order.status === 'pending' ? 'warning' :
                        order.status === 'failed' ? 'error' : 'default'
                      }
                    >
                      {order.status}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

